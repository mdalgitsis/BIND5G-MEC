import collectd  
import json

def cpu_load(ws, j_res, epc_ip):
    try:
        vl = collectd.Values(type='vcpu')
        vl.host = epc_ip
        vl.plugin = "CORE_resources"
        vl.plugin_instance = "mme"
        vl.type_instance = "single_core"
        vl.interval = 5
        if j_res['cpu']:
            val = j_res['cpu']['global']
            vl.dispatch(values=[val])
    except Exception as ex:
        print(ex)    

def emm_registered_ue_count(ws, j_res, epc_ip):
    vl = collectd.Values(type='count')
    vl.plugin="CORE_emm_registered_ue"
    vl.host=epc_ip
    vl.interval=5
    vl.dispatch(values=[j_res['emm_registered_ue_count']])


def s1_connections(ws, j_res, epc_ip):
    try:
        vl = collectd.Values(type='count')
        vl.host=epc_ip
        vl.plugin="CORE_s1_connections"
        vl.interval=5
        s1_con=j_res['s1_connections']
        for con in s1_con:
            vl.plugin_instance=str(con['enb_id'])
            vl.type_instance="'plmn':'" + con['plmn'] + "','enb_id_type':'" + con['enb_id_type'] + "','enb_id':'" + str(con['enb_id']) + "', 'ip_addr':'" + con['ip_addr'].split(":",1)[0] + "'"
            vl.dispatch(values=[con['emm_connected_ue_count']])
    except Exception as ex:
        print(ex)    

def ng_connections(ws, j_res, epc_ip):
    try:
        vl = collectd.Values(type='count')
        vl.host=epc_ip
        vl.plugin="CORE_ng_connections"
        vl.interval=5
        ng_con=j_res['ng_connections']
        for con in ng_con:
            vl.plugin_instance=str(con['ran_id'])
            vl.type_instance="'plmn':'" + con['plmn'] + "','ran_id_type':'" + con['ran_id_type'] + "','ran_id':'" + str(con['ran_id']) + "','ip_addr':'" + con['ip_addr'].split(":",1)[0] + "'"            
            vl.dispatch(values=[con['cn_connected_ue_count']])
    except Exception as ex:
        print(ex)      

def pdn_list(ws, j_res, epc_ip):
    try:
        vl = collectd.Values(type='pdn')
        vl.host=epc_ip
        vl.plugin="CORE_pdn_list"
        vl.interval=5
        ng_con=j_res['pdn_list']
        for con in ng_con:
            vl.type_instance="'access_point_name':" + con['access_point_name']
            vl.dispatch(values=[con["ul_bytes"], con["dl_bytes"]])
    except Exception as ex:
        print(ex)
        

def ue_info(ws, j_res, epc_ip):
    try:
        vl = collectd.Values(type='info')
        vl.plugin="CORE_ue"
        vl.interval=5
        ue_list=j_res['ue_list']
        for ue in ue_list:
            if 'm_tmsi' in ue:
                vl.plugin_instance=str(ue['imsi'])
                vl.type_instance='lte'
                registered = 0
                enb_ue_id = -1
                mme_ue_id = -1
                ran_id = -1
                ran_plmn = -1
                if ue['registered']:
                    registered = 1
                    if 'enb_ue_id' in ue:
                        enb_ue_id = ue['enb_ue_id']
                        mme_ue_id = ue['mme_ue_id']
                        ran_id = ue['enb_id']
                        ran_plmn = ue['enb_plmn']
                    bearers = ue['bearers']
                    dl_speed = 0
                    ul_speed = 0
                    pdu_session_id = -1
                    sst = -1
                    sd = -1
                    qos_flow_id = -1        
                    for bearer in bearers:
                        #Missing ipv6 (habra que poner if por si tiene ipv4 solo, ipv6 solo o tiene ambas)
                        vl.type_instance='lte' + " 'ip_addr':'" + bearer['ip'].split(":",1)[0] + "','apn_name':'" + bearer['apn'] + "'"
                        dl_speed = bearer['dl_total_bytes']
                        ul_speed = bearer['ul_total_bytes']
                        pdu_session_id = bearer['erab_id']
                        vl.dispatch(values=[dl_speed, ul_speed, enb_ue_id, mme_ue_id, registered, ran_id, ran_plmn, pdu_session_id, sst, sd, qos_flow_id])
            if '5g_tmsi' in ue:
                vl.plugin_instance=str(ue['imsi'])
                vl.type_instance='nr'
                registered = 0
                enb_ue_id = -1
                mme_ue_id = -1
                ran_id = -1
                ran_plmn = -1
                if ue['registered']:
                    registered = 1
                    if 'ran_ue_id' in ue:
                        enb_ue_id = ue['ran_ue_id']
                        mme_ue_id = ue['amf_ue_id']
                        ran_id = ue['ran_id']
                        ran_plmn = ue['ran_plmn']
                    bearers = ue['bearers']
                    dl_speed = 0
                    ul_speed = 0
                    pdu_session_id = -1
                    sst = -1
                    sd = -1
                    qos_flow_id = -1
                    for bearer in bearers:
                        #Missing ipv6 (habra que poner if por si tiene ipv4 solo, ipv6 solo o tiene ambas)
                        vl.type_instance='nr' + " 'ip_addr':'" + bearer['ip'].split(":",1)[0] + "','apn_name':'" + bearer['apn'] + "'"
                        dl_speed = bearer['dl_total_bytes']
                        ul_speed = bearer['ul_total_bytes']
                        pdu_session_id = bearer['pdu_session_id']
                        if 'sst' in bearer:
                            sst = bearer['sst']
                        if 'sd' in bearer:
                            sd = bearer['sd']
                        if 'qos_flow_id' in bearer:
                            qos_flow_id = bearer['qos_flow_id']
                        vl.dispatch(values=[dl_speed, ul_speed, enb_ue_id, mme_ue_id, registered, ran_id, ran_plmn, pdu_session_id, sst, sd, qos_flow_id])
    except Exception as ex:
        print(ex)      
