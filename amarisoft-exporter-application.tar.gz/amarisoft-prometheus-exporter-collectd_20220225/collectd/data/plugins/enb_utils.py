import collectd  
import json
from websocket import create_connection

def cpu_load(j_res, enb_id):
    try:
        vl = collectd.Values(type='vcpu')
        vl.host = enb_id
        vl.plugin = "RAN_resources"
        vl.plugin_instance = "enb"
        vl.type_instance = "single_core"
        vl.interval = 5
        if j_res['cpu']:
            val = j_res['cpu']['global']
            vl.dispatch(values=[val])
    except Exception as ex:
        print(ex)    


def get_ran_id(j_res):
    if j_res and j_res.get('global_enb_id'):
        return str(j_res['global_enb_id']['enb_id'])
    elif j_res and j_res.get('global_gnb_id'):
        return str(j_res['global_gnb_id']['gnb_id'])
    else:
        return '-1'

def get_lte_cells(j_res):
    cells = []
    if j_res and j_res.get('cells'):
        for key in j_res.get('cells'):
            cells.append(key)
    return cells

def get_nr_cells(j_res):
    cells = []
    if j_res and j_res.get('nr_cells'):
        for key in j_res.get('nr_cells'):
            cells.append(key)
    return cells                 


def global_ran_info(j_res,ran_id):

    vl = collectd.Values(type='global_ran_info')
    vl.plugin='RAN'
    vl.host=ran_id
    vl.interval=5
    index=1 

    if 'global_enb_id' in j_res:
        vl.plugin_instance="'plmn':'" +  str(j_res['global_enb_id']['plmn']) + "','enb_id_type':'" + j_res['global_enb_id']['enb_id_type'] + "','enb_id':'" + str(j_res['global_enb_id']['enb_id']) + "','enb_name':'" + j_res['global_enb_id']['enb_name'] + "'"
    if 'global_gnb_id' in j_res:
        vl.plugin_instance="'plmn':'" +  str(j_res['global_gnb_id']['plmn']) + "','gnb_id':'" + str(j_res['global_gnb_id']['gnb_id']) + "','gnb_name':'" + j_res['global_gnb_id']['gnb_name'] + "'"
    
    vl.dispatch(values=[index])


def cell_info(ws, j_res, ran_id, lte_cells, nr_cells):

    vl = collectd.Values(type='cell_info')
    vl.plugin='RAN'
    vl.host=ran_id
    vl.interval=5

    for cell in lte_cells:
        vl.plugin_instance=cell+",'mode':'"+j_res['cells'][cell]['mode']+",'dl_cyclic_prefix':'"+j_res['cells'][cell]['dl_cyclic_prefix']+",'ul_cyclic_prefix':'" + j_res['cells'][cell]['ul_cyclic_prefix'] + "'"
        vl.type_instance='lte'
        vl.dispatch(values=[j_res["cells"][cell]["n_antenna_dl"], j_res["cells"][cell]["n_antenna_ul"], j_res["cells"][cell]["gain"], j_res["cells"][cell]["dl_qam"], j_res["cells"][cell]["ul_qam"], j_res["cells"][cell]["n_id_cell"], j_res["cells"][cell]["band"], -1, -1, j_res["cells"][cell]["dl_lte_earfcn"], j_res["cells"][cell]["ul_lte_earfcn"], j_res["cells"][cell]["dl_freq"], j_res["cells"][cell]["ul_freq"], j_res["cells"][cell]["n_rb_dl"], j_res["cells"][cell]["n_rb_ul"], -1, j_res["cells"][cell]["rf_port"]])
    for cell in nr_cells:
        vl.plugin_instance=cell+",'mode':'" + str(j_res['nr_cells'][cell]['mode'])+ "'"
        vl.type_instance='nr'
        vl.dispatch(values=[j_res["nr_cells"][cell]["n_antenna_dl"], j_res["nr_cells"][cell]["n_antenna_ul"], j_res["nr_cells"][cell]["gain"], j_res["nr_cells"][cell]["dl_qam"], j_res["nr_cells"][cell]["ul_qam"], j_res["nr_cells"][cell]["n_id_nrcell"], j_res["nr_cells"][cell]["band"], j_res["nr_cells"][cell]["dl_nr_arfcn"], j_res["nr_cells"][cell]["ul_nr_arfcn"],-1 ,-1, j_res["nr_cells"][cell]["dl_freq"], j_res["nr_cells"][cell]["ul_freq"], j_res["nr_cells"][cell]["n_rb_dl"], j_res["nr_cells"][cell]["n_rb_ul"], j_res["nr_cells"][cell]["ssb_nr_arfcn"],j_res["nr_cells"][cell]["rf_port"]])


def plmn_list_info(ws, j_res, ran_id, lte_cells, nr_cells):
    try:

        index=1

        for cell in lte_cells:
            vl = collectd.Values(type='plmn_info_lte')
            vl.type_instance='lte'
            vl.plugin='RAN'
            vl.host=ran_id
            vl.interval=5

            for i in range(0, len(j_res["cells"][cell]["plmn_list"])):
                vl.plugin_instance=cell+ ", plmn_id:" + str(index)
                index+=1
                vl.dispatch(values=[j_res["cells"][cell]["plmn_list"][i]['plmn'],j_res["cells"][cell]["tac"]])

        index=1
        for cell in nr_cells:
            vl = collectd.Values(type='plmn_info_nr')
            vl.plugin='RAN'
            vl.host=ran_id
            vl.interval=5

            vl.type_instance='nr'
            for i in range(0, len(j_res["nr_cells"][cell]["plmn_list"])):
            
                for j in range(0, len(j_res["nr_cells"][cell]["plmn_list"][i]['plmn_ids'])):
                    index=1
                    for k in range(0, len(j_res["nr_cells"][cell]["plmn_list"][i]['nssai'])):
                        vl.plugin_instance=cell + ", tac:" + str(j_res["nr_cells"][cell]["plmn_list"][i]["tac"]) + ", plmn_id:" + j_res["nr_cells"][cell]["plmn_list"][i]["plmn_ids"][j] + ", slice_id:" + str(index)
                        index+=1
                        if 'sd' in j_res["nr_cells"][cell]["plmn_list"][i]['nssai'][k]:
                            vl.dispatch(values=[j_res["nr_cells"][cell]["plmn_list"][i]['nssai'][k]["sst"],j_res["nr_cells"][cell]["plmn_list"][i]['nssai'][k]["sd"]])
                        else:
                            vl.dispatch(values=[j_res["nr_cells"][cell]["plmn_list"][i]['nssai'][k]["sst"],-1])
    
    except Exception as ex:
        print(ex)
        
def tx_channnel_info(j_res,ran_id):
    vl = collectd.Values(type='tx_channel_info')
    vl.plugin='RAN'
    vl.host=ran_id
    vl.interval=5

    values = []
    for i in range (0,len(j_res['tx_channels'])):
        
        values.append(j_res['tx_channels'][i]['gain'])
        values.append(j_res['tx_channels'][i]['freq'])

        vl.plugin_instance="rf_port:"+ str(j_res['tx_channels'][i]['port'])
        vl.dispatch(values=values)
        values = []


def rx_channel_info(j_res,ran_id):
    vl = collectd.Values(type='rx_channel_info')
    vl.plugin='RAN'
    vl.host=ran_id
    vl.interval=5

    values = []
    for i in range (0,len(j_res['rx_channels'])):
        
        values.append(j_res['rx_channels'][i]['gain'])
        values.append(j_res['rx_channels'][i]['freq'])

        vl.plugin_instance="rf_port:" + str(j_res['rx_channels'][i]['port'])
        vl.dispatch(values=values)
        values = []

def cell_ulFreq(j_res,ran_id):
    cells = []
    vl = collectd.Values(type='ul_freq')  # This type must be in the DB
    vl.plugin='RAN_freq' # This is the name of the metric --> colled_<plugin>_>type>
    vl.plugin_instance='ul' # This is an extra label for the target/metric --> <plugin>=<plugin_instance>
    vl.type_instance='nr' # This is an extra label for the target/metric --> type=<type_instance>
    vl.host=ran_id # This is an extra label for the target/metric --> exported_instance=<host>
    vl.interval=5
    if j_res and j_res.get('nr_cells'):
        for key in j_res.get('nr_cells'):
            cells.append(key)

    for cell in cells:
        vl.dispatch(values=[j_res["nr_cells"][cell]['ul_freq']]) # These are the values of the metrics (the same number of values as the type (ul_freq) has in DB)

def rf_stats(ws, j_res, enb_id, lte_cells, nr_cells):
    vl = collectd.Values(type='rf_stats')
    vl.plugin='RAN'
    vl.plugin_instance='none'
    vl.host=enb_id
    vl.interval=5
    vl.dispatch(values=[j_res["rf"]["rx_sample_rate"], j_res["rf"]["tx_sample_rate"],j_res["rf"]["rx_cpu_time"], j_res["rf"]["tx_cpu_time"],j_res["rf"]["rxtx_delay_min"], j_res["rf"]["rxtx_delay_avg"],j_res["rf"]["rxtx_delay_max"], j_res["rf"]["rxtx_delay_sd"]])


def sample_stats_tx(ws, j_res, enb_id, lte_cells, nr_cells):
    vl = collectd.Values(type='sample_stats_tx')
    vl.plugin='RAN'
    vl.plugin_instance='none'
    vl.host=enb_id
    vl.interval=5
    values = []
    for i in range (0,len(j_res['samples']['tx'])):
        values.append(j_res['samples']['tx'][i]['rms'])
        values.append(j_res['samples']['tx'][i]['max'])
        values.append(j_res['samples']['tx'][i]['sat'])
        values.append(j_res['samples']['tx'][i]['count'])
        vl.plugin_instance=str(i)
        vl.dispatch(values=values)
        values = []

def sample_stats_rx(ws, j_res, enb_id, lte_cells, nr_cells):
    vl = collectd.Values(type='sample_stats_rx')
    vl.plugin='RAN'
    vl.plugin_instance='none'
    vl.host=enb_id
    vl.interval=5
    values = []
    for i in range (0,len(j_res['samples']['rx'])):
        values.append(j_res['samples']['rx'][i]['rms'])
        values.append(j_res['samples']['rx'][i]['max'])
        values.append(j_res['samples']['rx'][i]['sat'])
        values.append(j_res['samples']['rx'][i]['count'])
        vl.plugin_instance=str(i)
        vl.dispatch(values=values)
        values = []

def rf_ports_stats(ws, j_res, enb_id, lte_cells, nr_cells):
    vl = collectd.Values(type='rf_ports_stats')
    vl.plugin='RAN'
    vl.plugin_instance='none'
    vl.host=enb_id
    vl.interval=5
    values = []
    
    rf_port = []
    if j_res and j_res.get('rf_ports'):
        for key in j_res.get('rf_ports'):
            rf_port.append(key)

    for port in rf_port:
        values.append(j_res['rf_ports'][port]['rxtx_delay']['min'])
        values.append(j_res['rf_ports'][port]['rxtx_delay']['max'])
        values.append(j_res['rf_ports'][port]['rxtx_delay']['avg'])
        values.append(j_res['rf_ports'][port]['rxtx_delay']['sd'])
        vl.plugin_instance=port
        vl.dispatch(values=values)
        values = []

def cell_stats(ws, j_res, enb_id, lte_cells, nr_cells):
    vl = collectd.Values(type='cell_stats')
    vl.plugin='RAN'
    vl.plugin_instance='none'
    vl.host=enb_id
    vl.interval=5
    for cell in lte_cells:
        vl.plugin_instance=cell
        vl.type_instance='lte'
        vl.dispatch(values=[j_res["cells"][cell]["dl_bitrate"], j_res["cells"][cell]["ul_bitrate"], j_res["cells"][cell]["dl_tx"], j_res["cells"][cell]["ul_tx"], j_res["cells"][cell]["dl_retx"], j_res["cells"][cell]["ul_retx"]])
    for cell in nr_cells:
        vl.plugin_instance=cell
        vl.type_instance='nr'
        vl.dispatch(values=[j_res["cells"][cell]["dl_bitrate"], j_res["cells"][cell]["ul_bitrate"], j_res["cells"][cell]["dl_tx"], j_res["cells"][cell]["ul_tx"], j_res["cells"][cell]["dl_retx"], j_res["cells"][cell]["ul_retx"]])

def ue_count(j_res,ran_id):
    vl = collectd.Values(type='count')
    vl.plugin = 'RAN_ue'
    vl.plugin_instance = 'total'
    vl.host = ran_id
    vl.type_instance = 'none'
    vl.interval = 5
    vl.dispatch(values=[len(j_res['ue_list'])])        

def imsi_id(enb_ip):
    try:
        ws = create_connection('ws://%s:9000' % enb_ip)
        ws.recv()
        ws.send('{"message":"ue_get"}')   
        result =  ws.recv()
        if ws:
            ws.shutdown
            ws.close()
        else:
            return []
        imsi_list = []       
        j_res = json.loads(result)
        ue_list=j_res['ue_list']
        for ue in ue_list:
            if 'enb_id' in ue:
                imsi=str(ue['imsi'])
                if ue['registered']:
                    mme_ue_id = ue['mme_ue_id']
                    imsi_list.append({'imsi':imsi,'mme_ue_id':mme_ue_id})
            if 'ran_id' in ue:
                imsi=str(ue['imsi'])
                if ue['registered']:
                    mme_ue_id = ue['ran_ue_id']
                    imsi_list.append({'imsi':imsi,'ran_ue_id':mme_ue_id})
        return imsi_list
    except Exception as ex:
        print(ex)      


def ue_bitrate(j_res, imsi_list, ran_id):
    for i in range (0,len(j_res['ue_list'])):
        if(len(j_res['ue_list'][i]['cells'][0]) > 1):
            if 'mme_ue_id' in j_res['ue_list'][i]:
                mme_ue_id = j_res['ue_list'][i]['mme_ue_id']
                for imsi in imsi_list:
                    if 'mme_ue_id' in imsi:
                        if imsi['mme_ue_id'] == mme_ue_id:
                            vl = collectd.Values(type='ue_stats_bitrate')
                            vl.plugin='RAN'
                            vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
                            vl.host=ran_id
                            vl.type_instance='lte'
                            vl.interval=5
                            vl.dispatch(values=[j_res['ue_list'][i]['cells'][0]['ul_bitrate'],j_res['ue_list'][i]['cells'][0]['dl_bitrate']])
            if 'ran_ue_id' in j_res['ue_list'][i]:
                ran_ue_id = j_res['ue_list'][i]['ran_ue_id']
                for imsi in imsi_list:
                    if 'ran_ue_id' in imsi:
                        if imsi['ran_ue_id'] == ran_ue_id:
                            vl = collectd.Values(type='ue_stats_bitrate')
                            vl.plugin='RAN'
                            vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
                            vl.host=ran_id
                            vl.type_instance='nr'
                            vl.interval=5
                            vl.dispatch(values=[j_res['ue_list'][i]['cells'][0]['ul_bitrate'],j_res['ue_list'][i]['cells'][0]['dl_bitrate']])


def ue_stats(j_res, imsi_list, ran_id):
   for i in range (0,len(j_res['ue_list'])):
        if(len(j_res['ue_list'][i]['cells'][0]) > 1):
            if 'mme_ue_id' in j_res['ue_list'][i]:
                mme_ue_id = j_res['ue_list'][i]['mme_ue_id']
                for imsi in imsi_list:
                    if 'mme_ue_id' in imsi:
                        if imsi['mme_ue_id'] == mme_ue_id:
                            vl = collectd.Values(type='stats')
                            vl.plugin='RAN_ue'
                            vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
                            vl.host=ran_id
                            vl.type_instance='lte'
                            vl.interval=5
                            values = []
                            values.append(j_res['ue_list'][i]['cells'][0]['dl_mcs'])
                            if 'ul_mcs' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ul_mcs'])
                            else:
                                values.append(0)
                            values.append(j_res['ue_list'][i]['cells'][0]['cqi'])
                            values.append(j_res['ue_list'][i]['cells'][0]['dl_tx'])
                            values.append(j_res['ue_list'][i]['cells'][0]['ul_tx'])
                            values.append(j_res['ue_list'][i]['cells'][0]['dl_retx'])
                            values.append(j_res['ue_list'][i]['cells'][0]['ul_retx'])

                            if 'pusch_snr' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['pusch_snr'])
                            else:
                                values.append(-1)

                            if 'epre' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['epre'])
                            else:
                                values.append(-1)

                            if 'ul_phr' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ul_phr'])
                            else:
                                values.append(-1)
                
                            if 'ul_path_loss' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ul_path_loss'])
                            else:
                                values.append(-1)
                            
                            if 'ri' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ri'])
                            else:
                                values.append(-1)
                            
                            if 'turbo_decoder_min' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['turbo_decoder_min'])
                            else:
                                values.append(-1)
                            
                            if 'turbo_decoder_avg' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['turbo_decoder_avg'])
                            else:
                                values.append(-1)
                            
                            if 'turbo_decoder_max' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['turbo_decoder_max'])
                            else:
                                values.append(-1)
                            
                            if 'pucch1_snr' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['pucch1_snr'])
                            else:
                                values.append(-1)
                            
                            if 'initial_ta' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['initial_ta'])
                            else:
                                values.append(-1)

                            vl.dispatch(values=values)
            if 'ran_ue_id' in j_res['ue_list'][i]:
                ran_ue_id = j_res['ue_list'][i]['ran_ue_id']
                for imsi in imsi_list:
                    if 'ran_ue_id' in imsi:
                        if imsi['ran_ue_id'] == ran_ue_id:
                            vl = collectd.Values(type='stats')
                            vl.plugin='RAN_ue'
                            vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'" 
                            vl.host=ran_id
                            vl.type_instance='nr'
                            vl.interval=5
                            values = []
                            values.append(j_res['ue_list'][i]['cells'][0]['dl_mcs'])
                            if 'ul_mcs' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ul_mcs'])
                            else:
                                values.append(0)
                            values.append(j_res['ue_list'][i]['cells'][0]['cqi'])
                            values.append(j_res['ue_list'][i]['cells'][0]['dl_tx'])
                            values.append(j_res['ue_list'][i]['cells'][0]['ul_tx'])
                            values.append(j_res['ue_list'][i]['cells'][0]['dl_retx'])
                            values.append(j_res['ue_list'][i]['cells'][0]['ul_retx'])

                            if 'pusch_snr' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['pusch_snr'])
                            else:
                                values.append(-1)

                            if 'epre' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['epre'])
                            else:
                                values.append(-1)

                            if 'ul_phr' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ul_phr'])
                            else:
                                values.append(-1)

                            if 'ul_path_loss' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ul_path_loss'])
                            else:
                                values.append(-1)

                            if 'ri' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['ri'])
                            else:
                                values.append(-1)

                            if 'turbo_decoder_min' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['turbo_decoder_min'])
                            else:
                                values.append(-1)

                            if 'turbo_decoder_avg' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['turbo_decoder_avg'])
                            else:
                                values.append(-1)

                            if 'turbo_decoder_max' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['turbo_decoder_max'])
                            else:
                                values.append(-1)

                            if 'pucch1_snr' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['pucch1_snr'])
                            else:
                                values.append(-1)

                            if 'initial_ta' in j_res['ue_list'][i]['cells'][0]:
                                values.append(j_res['ue_list'][i]['cells'][0]['initial_ta'])
                            else:
                                values.append(-1)

                            vl.dispatch(values=values)

#def ue_snr(j_res, imsi_list, ran_id):
#    for i in range (0,len(j_res['ue_list'])):
#        if(len(j_res['ue_list'][i]['cells'][0]) > 1):
#            if 'mme_ue_id' in j_res['ue_list'][i]:
#                mme_ue_id = j_res['ue_list'][i]['mme_ue_id']
#                for imsi in imsi_list:
#                    if 'mme_ue_id' in imsi:
#                        if imsi['mme_ue_id'] == mme_ue_id:
#                            if 'pusch_snr' in j_res['ue_list'][i]['cells'][0]:
#                                vl = collectd.Values(type='snr')
#                                vl.plugin='RAN_ue'
#                                vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
#                                vl.host=ran_id
#                                vl.type_instance='pusch'
#                                vl.interval=5
#                                vl.dispatch(values=[j_res['ue_list'][i]['cells'][0]['pusch_snr']])
#                            if 'pucch1_snr' in j_res['ue_list'][i]['cells'][0]:
#                                vl = collectd.Values(type='snr')
#                                vl.plugin='RAN_ue'
#                                vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
#                                vl.host=ran_id
#                                vl.type_instance='pusch'
#                                vl.interval=5
#                                vl.dispatch(values=[j_res['ue_list'][i]['cells'][0]['pucch1_snr']])    
#            if 'ran_ue_id' in j_res['ue_list'][i]:
#                ran_ue_id = j_res['ue_list'][i]['ran_ue_id']
#                for imsi in imsi_list:
#                    if 'ran_ue_id' in imsi:
#                        if imsi['ran_ue_id'] == ran_ue_id:
#                            if 'pusch_snr' in j_res['ue_list'][i]['cells'][0]:
#                                vl = collectd.Values(type='snr')
#                                vl.plugin='RAN_ue'
#                                vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
#                                vl.host=ran_id
#                                vl.type_instance='pusch'
#                                vl.interval=5
#                                vl.dispatch(values=[j_res['ue_list'][i]['cells'][0]['pusch_snr']])
#                            if 'pucch1_snr' in j_res['ue_list'][i]['cells'][0]:
#                                vl = collectd.Values(type='snr')
#                                vl.plugin='RAN_ue'
#                                vl.plugin_instance=imsi['imsi'] + "'ran_ue_id':'" +  str(j_res['ue_list'][i]['ran_ue_id']) + "','core_ue_id':'" + str(j_res['ue_list'][i]['amf_ue_id']) + "'"
#                                vl.host=ran_id
#                                vl.type_instance='pusch'
#                                vl.interval=5
#                                vl.dispatch(values=[j_res['ue_list'][i]['cells'][0]['pucch1_snr']])    

def qos_flow_get(j_res, imsi_list, ran_id, enb_ip):
    try:

        for i in range (0,len(j_res['qos_flow_list'])):
            if(len(j_res['qos_flow_list'][i]) > 1):
                if 'ran_ue_id' in j_res['qos_flow_list'][i]:
                    ran_ue_id = j_res['qos_flow_list'][i]['ran_ue_id']
                    for imsi in imsi_list:
                        if 'ran_ue_id' in imsi:
                            if imsi['ran_ue_id'] == ran_ue_id:
                                vl = collectd.Values(type='info_ran')
                                vl.host=enb_ip
                                vl.plugin="RAN_qos_flow"
                                vl.interval=5
                                qos_con=j_res['qos_flow_list']
                                dl_speed = 0
                                ul_speed = 0
                                for con in qos_con:
                                    vl.plugin_instance=enb_ip
                                    qfi_con=con['qfi_list']
                                    for con1 in qfi_con:
                                        vl.type_instance=imsi['imsi'] + " 'ran_ue_id':'" +  str(con['ran_ue_id'])+ "','pdu_session_id':'" + str(con['pdu_session_id']) + "','sst':'" + str(con['sst']) + "','qfi':'" + str(con1['qfi'])+ "', '5qi':'" + str(con1['5qi']) + "'"

                                dl_speed = dl_speed + con['dl_total_bytes']
                                ul_speed = ul_speed + con['ul_total_bytes']
                                vl.dispatch(values=[dl_speed, ul_speed])

    except Exception as ex:
        print(ex)



def s1_count(j_res, enb_ip):
    try:
        vl = collectd.Values(type='count')
        vl.host=enb_ip
        vl.plugin="RAN_s1_connections"
        vl.interval=5
        s1_con=j_res['s1_list']
        index=0
        for con in s1_con:
            vl.plugin_instance=enb_ip
            vl.type_instance="'state':'" + con['state'] + "'"
            index += 1
            vl.dispatch(values=[index])
    except Exception as ex:
        print(ex)



def ng_count(j_res, enb_ip):
    try:
        vl = collectd.Values(type='count')
        vl.host=enb_ip
        vl.plugin="RAN_ng_connections"
        vl.interval=5
        ng_con=j_res['ng_list']
        index = 0 

        for con in ng_con:
            vl.plugin_instance=enb_ip
            vl.type_instance="'state':'" + con['state'] + "'"
            index += 1
            vl.dispatch(values=[index])
    except Exception as ex:
        print(ex)
